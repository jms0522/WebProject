alert("아이디 혹은 비밀번호를 확인하세요");
location.href = "/loginPage";

