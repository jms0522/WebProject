package com.example.basic.database.dao;

public interface WebDao {

}
