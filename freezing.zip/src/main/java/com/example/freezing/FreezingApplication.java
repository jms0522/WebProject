package com.example.freezing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FreezingApplication {

	public static void main(String[] args) {
		SpringApplication.run(FreezingApplication.class, args);
	}

}
